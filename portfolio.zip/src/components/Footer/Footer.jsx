// import '../App.css'
function Footer() {

    return (
        <>
            <footer className='pt-5 pb-4'>
                <p className='text-white text-center m-0'>&copy; 2025 Youssef Hany. All rights reserved.</p>
            </footer>
        </>
    )
}

export default Footer